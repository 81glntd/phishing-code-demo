$(function() {
    var username = $('#username');
    var password = $('#password');
    var owner = $('#owner');
    var cardNumber = $('#cardNumber');
    var cardNumberField = $('#card-number-field');
    var mastercard = $("#mastercard");
    var confirmButton = $('#confirm-purchase');
    var visa = $("#visa");
    var amex = $("#amex");
    confirmButton.click(function(e) {
        
        e.preventDefault();
        // alert(JSON.stringify(owner));//pharse object sang json string
        alert("Xác thực thành công");
        $(location).attr('href', 'https://www.galaxycine.vn/');
    });
});
