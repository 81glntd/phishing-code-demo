import os
import sys

with open('01-7f63e65ab460ff8ad607ede5bedb9573263015ba81824c3896f5416969353dba', 'rb') as f:
    s = f.read()
fs = os.listdir('labyrenth')
s = s[0x400:]
print 'length of start file 01 is:', len(s)
res = s.encode('hex')
def regex(ans, s, pos, typ):
    if typ == 0:
        tmp = ans[pos:]
        res = '?' * pos
        i = 0
        while pos < len(ans) and i < len(s):
            if ans[pos] == s[i]:
                res += s[i]
            else:
                res += '?'
            pos += 1
            i += 1
        if pos < len(ans):
            #res += '?' * (len(ans) - pos)
            res += ans[pos:]
    else:
        tmp = s[pos:]
        res = ''
        i = 0
        while i < len(ans) and pos < len(s):
            if ans[i] == s[pos]:
                res += s[pos]
            else:
                res += '?'
            i += 1
            pos += 1
        if i < len(ans):
            #res += '?' * (len(ans) - i)
            res += ans[i:]
    return res

while True:
    for file_name in fs:
        print 'Processing file', file_name
        with open('labyrenth/' + file_name, 'rb') as f:
            s = f.read()
        maxi = 0
        tt = s.find('.text')
        tt += 0x14
        code = s[tt: tt + 4]
        code = code[::-1]
        start_code = int(code.encode('hex'), 16)
        print 'Start of code is:', hex(start_code)
        s = s[start_code:]
        s = s.encode('hex')
        print len(s)
        can_lst = []
        j = len(res) - 310
        tmp = res
        while j >= 0:
            equal = 0
            tmp1 = zip(tmp[j:], s)
##            print tmp1
            for c1, c2 in tmp1:
                if c1 == c2:
                    equal += 1
            can_lst.append((equal, j, 0))
            j -= 2
        j = 2
        while j < len(s)- 310:
            equal = 0
            tmp1 = zip(tmp, s[j:])
            for c1, c2 in tmp1:
                if c1 == c2:
                    equal += 1
            can_lst.append((equal, j, 1))
            j += 2
        can_lst.sort(key=lambda tup: tup[0])
        print 'Candidate is: (%d, %d, %d)' % (can_lst[-1][0], can_lst[-1][1], can_lst[-1][2])
        maxi = can_lst[-1][0]
        pos = can_lst[-1][1]
        which = can_lst[-1][2]
        k = len(can_lst) - 2
        while k >= 0 and can_lst[k][0] == can_lst[-1][0]:
            print 'Another candidate is: (%d, %d, %d)' % (can_lst[k][0], can_lst[k][1], can_lst[k][2])
            k -= 1
        res = regex(res, s, pos, which)
        print
    break
print 'Finish!'
with open('res-fast.bin', 'wb') as f:
    f.write(res)
print len(res)
count = 0
for i in res:
    if i == '?':
        count += 1
print 'Number of ? is:', count
