<!DOCTYPE html>
<html lang="en">
<center>
<style>
    body {
    background: url("1m4g3s/background.jpg") no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    }
</style>

<?php
//truecase: config /*' or table_name LIKE '%config
$servername = "localhost";
$username = "root";
$password = "@bcd1234";
$dbname = "simplelogin";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST["username"]) && !empty($_POST["username"]) && isset($_POST["password"]) && !empty($_POST["password"]))
{
    $username = mysqli_real_escape_string($conn,$_POST['username']);// No more SQL Injection.
    $password = mysqli_real_escape_string($conn,$_POST['password']);// No more SQL Injection.
    $sig = $_POST['sig'];
    if(preg_match('#"|sleep|benchmark|floor|rand|count|users|username|password|id#is',$sig))
        echo "<span style='color: red;'/><center><h1><tr>Nothing is easy. Go away dude!!!!</h1></center></style></span>";
    $sql  = "SELECT * FROM users WHERE username='$username' AND password='$password' limit 1";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) == 0)
        echo "<span style='color: red;'/><center><h1><tr>Nothing is easy. Go away dude!!!!</h1></center></style></span>";
    else{
        $sql1 = "SELECT column_name from information_schema.columns WHERE table_name = '$sig' limit 1";
        $check1 = mysqli_fetch_array(mysqli_query($conn, $sql1));
        if ($check1["column_name"] == "id")
        {
            $sql2 = "UPDATE $sig SET value=true'*/ SET value=true WHERE username='$username'";
            $result1 = mysqli_fetch_array(mysqli_query($conn, $sql1));
            if(mysqli_num_rows($result1) == 0){
                    $result2 = mysqli_fetch_array(mysqli_query($conn, $sql2));
                    $row2 = mysqli_fetch_array($result2);
                    $check2 = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM config where username='$username' limit 1"));
                    if ($check2['value'] == true){
                        echo "<span style='color: blue;'/><center><h1><tr>FLAG: MeepwnCTF{all the roads lead to rome}</h1></center></style></span>";
                    }
                    else echo "<span style='color: red;'/><center><h1><tr>Try harder, dude. No FLAG for you!!!!</h1></center></style></span>";
                }
        }
        while ($row = mysqli_fetch_array($result)) {
            $u1  = $row['username'];
            echo "<span style='color: red;'/><center><h1><tr>Hello: <td>$u1</td></h1></center></style></span>";
        }
        echo '<span style="color: violet;"/><center><b><h3><p>Hmmmm, I think you know what should to do!!!!</p><h3></b></center></span>';
    }
}
mysqli_close($conn);
?>
<!-- test/__test__ -->
<head>
    <meta charset="utf-8">
    <title>Simple Login</title>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700|Lato:400,100,300,700,900' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="login-box animated fadeInUp">
            <div class="box-header">
                <font color="green" size="6"><h2><b>Let's Rock!!!<b></h2>
            </div>
            <form action="index.php" method="POST">
            <label for="username">Username</label>
            <br/>
            <input type="text" id="username" name="username">
            <br/>
            <label for="password">Password</label>
            <br/>
            <input type="password" id="password" name="password">
            <br/>
            <button type="submit">Sign In</button>
            <br/>
            </form>
            <center>
            <font color="violet"><h2><b>...or relax here!!!<b></h2>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/4AqjqOqNrjw" frameborder="0" allowfullscreen></iframe>
            </center>
        </div>
    </div>
</body>
<script>
    $(document).ready(function () {
        $('#logo').addClass('animated fadeInDown');
        $("input:text:visible:first").focus();
    });
    $('#username').focus(function() {
        $('label[for="username"]').addClass('selected');
    });
    $('#username').blur(function() {
        $('label[for="username"]').removeClass('selected');
    });
    $('#password').focus(function() {
        $('label[for="password"]').addClass('selected');
    });
    $('#password').blur(function() {
        $('label[for="password"]').removeClass('selected');
    });
</script>
</center>
</html>
