<!-- test/__test__ -->
<!-- GLHF :doge: -->
<!DOCTYPE html>
<html lang="en">
<center>
<style>
    body {
    background: url("1m4g3s/background.jpg") no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    }
</style>

<?php
$servername = "localhost";
$username = "root";
$password = "@bcd1234";
$dbname = "flagshop";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if(isset($_POST["username"]) && !empty($_POST["username"]) && isset($_POST["password"]) && !empty($_POST["password"]))
{
    $username = mysqli_real_escape_string($conn,$_POST['username']);// No more SQL Injection.
    $password = mysqli_real_escape_string($conn,$_POST['password']);// No more SQL Injection.
    $sql  = "SELECT * FROM users WHERE username='$username' AND password='$password' limit 1";
    $result = mysqli_query($conn, $sql);
    if(mysqli_num_rows($result) == 0)
        echo "<span style='color: red;'/><center><h1><tr>Nothing is easy. Go away dude!!!!</h1></center></style></span>";
    else{
        $sql1  = "SELECT * FROM buyflag WHERE username='admin' limit 1";
        $check1 = mysqli_fetch_array(mysqli_query($conn, $sql1));
        echo "<tr><center><strong><td><font color='yellow' size=8 >Need " . $check1["value"] . " gold to buy flag dude!!!</font></td>";
        echo "<tr><center><strong><td><font color=#ff3300s size=8 >==========================</font></td>";
        $sql2  = "SELECT * FROM buyflag WHERE username='$username' limit 1";
        $result2 = mysqli_fetch_array(mysqli_query($conn, $sql2));
        echo "<tr><center><strong><td><font color='red' size=8 >Hello: " . $result2["username"] . "</font></td>";
        echo "<tr><center><strong><td><font color='red' size=8 >You have: " . $result2["value"] . " gold</font></td>";
        
        if(isset($_POST['buyflag']) && !empty($_POST['buyflag']))
        {
            $buyflag=$_POST["buyflag"];
            $buyflag=preg_replace('/information_schema|drop|join|-|#| |floor|=/i','~nothingisezdude~',strtolower($buyflag));
            echo $buyflag;
            $sql3 = mysqli_query($conn,"UPDATE buyflag SET value=value+1 WHERE username='admin'");
            $sql4 = mysqli_query($conn,"UPDATE buyflag SET value=value+1 WHERE username='$buyflag'");
        }
    }
}
mysqli_close($conn);
?>
<head>
    <meta charset="utf-8">
    <title>Just another flag shop</title>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700|Lato:400,100,300,700,900' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="login-box animated fadeInUp">
            <div class="box-header">
                <font color=#0099ff size="6"><h2><b>Let's Rock!!!<b></h2>
            </div>
            <form action="index.php" method="POST">
            <label for="username">Username</label>
            <br/>
            <input type="text" id="username" name="username">
            <br/>
            <label for="password">Password</label>
            <br/>
            <input type="password" id="password" name="password">
            <br/>
            <label for="buyflag"><font color=#990033 size="4"><h1>Input your name to buy more gold</h1></font></label>
            <br/>
            <input type="text" id="buyflag" name="buyflag">
            <br/>
            <button type="submit">Buy more gold</button>
            <br/>
            </form>
            <center>
            <font color=#cc00ff><h2><b>...or relax here!!!<b></h2>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/4AqjqOqNrjw" frameborder="0" allowfullscreen></iframe>
            </center>
        </div>
    </div>
</body>
<script>
    $(document).ready(function () {
        $('#logo').addClass('animated fadeInDown');
        $("input:text:visible:first").focus();
    });
    $('#username').focus(function() {
        $('label[for="username"]').addClass('selected');
    });
    $('#username').blur(function() {
        $('label[for="username"]').removeClass('selected');
    });
    $('#password').focus(function() {
        $('label[for="password"]').addClass('selected');
    });
    $('#password').blur(function() {
        $('label[for="password"]').removeClass('selected');
    });
</script>
</center>
</html>
